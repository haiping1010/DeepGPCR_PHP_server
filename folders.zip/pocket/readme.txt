grep '^ATOM\|^TER\|^END' 6q23.pdb | grep ' A ' > 6q23_w.pdb

grep 'H 100' 6q20.pdb | grep ATOM  > ligand.pdb






