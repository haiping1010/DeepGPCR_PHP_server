cat    center.txt  | while read line
do

IFS=' ' read -r -a array <<< $line
##wget 'http://zinc15.docking.org/substances/'${array[0]}'.sdf'

cp -r  all/${array[0]}'.sdf'  .

done
