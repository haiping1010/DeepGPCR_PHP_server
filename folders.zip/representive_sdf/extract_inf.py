import sys
import os
input= sys.argv[1]
fr=open(input,'r')

arr=fr.readlines()
oldline=''
content=[]
row_line=''
for name in arr:
    
    if  'zinc_id'  in oldline:
        row_line=''
        row_line=name.strip()
        #content.append(name.strip())
    if   'class'   in oldline:
        row_line=row_line+' ' +name.strip()
        #content.append(name.strip())
    if  'isCentroid'  in oldline:
        row_line=row_line+ ' ' +name.strip()
        content.append(row_line)
    oldline=name

for name in content:
    print name
